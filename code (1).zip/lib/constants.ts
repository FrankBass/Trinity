export const CAMPAIGN_COMMISSION_RATE = 0.2 // 20% commission rate
